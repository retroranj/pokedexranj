package com.example.demo;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileReader;
import java.util.Iterator;
import java.io.BufferedReader;


import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;



public class PokedexDao {
	private final String filePath = "pokemon.json";
	
	//inputs
	String qty = "";
	String type_name = "";
	String type_id = "";
	String statsBa = "";
	String statsBs = "";
	String statsBd = "";
	String sortfield = "";
	int maxRecords = 0;

	ArrayList<JSONObject> returnList = null;
	String returnString = "";
	public PokedexDao () {
		this.returnList = new ArrayList<JSONObject>()	;	
		// returnString = this.getAll();
 		returnString  = this.displayAll();
	} // end DAO Constructor
	
	public String getAllRecords()  {
//		this.returnString.replace(",", "<BR>,");
//		this.returnString.replace("}", "<BR>}");

		return this.returnString;
	}
	
	private String displayAll() {
		String response = "";
		try { 
			FileReader reader = new FileReader("pokemon.json") ;
	        // read the json file
	    	
	        JSONParser jsonParser = new JSONParser();
	        JSONArray pokemonList = (JSONArray) jsonParser.parse(reader);
	        
	        System.out.println(pokemonList.get(0));
	        System.out.println(pokemonList.get(1));
	        for (int i = 0; i < pokemonList.size(); i++) {
	        	JSONObject pokemon = (JSONObject)pokemonList.get(i);
	        	this.returnList.add(pokemon);
	        	String s = "\n" + pokemon.toJSONString() + "\n";
	        	response += s;
	        	System.out.println("The " + i + " element of the array: " + s );
	        	String name = (String)pokemon.get("name");
	        	System.out.println("pokemon name is " + name);
	        	JSONArray types = (JSONArray)pokemon.get("types");
	        	System.out.println("pokemon types is " + types);
	        	JSONObject stats = (JSONObject)pokemon.get("stats");
	        	System.out.println("pokemon stats is " + stats);
	        }
	/*            // get a String from the JSON object
	        String firstName = (String) jsonObject.get("firstname");
	        System.out.println("The first name is: " + firstName);
	
	        // get a number from the JSON object
	        long id = (long) jsonObject.get("id");
	        System.out.println("The id is: " + id);
	
	        // get an array from the JSON object
	        JSONArray lang = (JSONArray) jsonObject.get("languages");
	
	        // take the elements of the json array
	        for (int i = 0; i < lang.size(); i++) {
	            System.out.println("The " + i + " element of the array: " + lang.get(i));
	        }
	        Iterator i = lang.iterator();
	
	        // take each value from the json array separately
	        while (i.hasNext()) {
	            JSONObject innerObj = (JSONObject) i.next();
	            System.out.println("language " + innerObj.get("lang") +
	                    " with level " + innerObj.get("knowledge"));
	        }
	        // handle a structure into the json object
	        JSONObject structure = (JSONObject) jsonObject.get("job");
	        System.out.println("Into job structure, name: " + structure.get("name"));
	*/
	    } catch (Exception ex) {
	        ex.printStackTrace();
	    }			
		
		return "[" + response + "]";
	}
	
	public String filterByName(String name) {
		System.out.println("name filter is " +name);
		String nameValue = name.split(":")[1];
		System.out.println("name value is " +nameValue);
		
		String response = "";
		
		
		System.out.println(this.returnList.size());
		for (int i = 0; i < this.returnList.size(); i++) {
        	JSONObject pokemon = (JSONObject)this.returnList.get(i);
        	String jsonNameValue = (String)pokemon.get("name");
        	if (nameValue.equals(jsonNameValue) ) {
        		System.out.println("Match found ");
	        	String s = "\n" + pokemon.toJSONString() + "\n";
        		response += s;
        	
        	}
		}
		
		return response;
	}
	public String filterByType(String type) {
		System.out.println("type filter is " +type);
		String typeName = type.split(":")[0];
		String typeValue = type.split(":")[1];
		System.out.println("type name is " +typeName);
		
		String response = "";
		
		
		System.out.println(this.returnList.size());
		for (int i = 0; i < this.returnList.size(); i++) {
        	JSONObject pokemon = (JSONObject)this.returnList.get(i);
        	JSONArray pokemonTypeList = (JSONArray) pokemon.get("types");
        	for (int j = 0; j < pokemonTypeList.size() ; j++) {
        		JSONObject pokemonType = (JSONObject)pokemonTypeList.get(j);
               	String jsonTypeValue = (String)pokemonType.get(typeName);
            	System.out.println("POKEMON typename VALUE " + jsonTypeValue);

            	if (typeValue.equals(jsonTypeValue) ) {
            		System.out.println("Match found ");
    	        	String s = "\n" + pokemon.toJSONString() + "\n";
            		response += s;
            		break;	
            	}
        	}
       	
		}
		return response;

		
	}
	public String filterByStats(String stats) {
		String response = "";
		System.out.println("stats filter is " +stats);
		String statsType = stats.split(":")[0];
		System.out.println("stats type  is " +statsType);

		String statsValue = stats.split(":")[1];
		System.out.println("stats value is " +statsValue);

		System.out.println(this.returnList.size());
		for (int i = 0; i < this.returnList.size(); i++) {
        	JSONObject pokemon = (JSONObject)this.returnList.get(i);
        	JSONObject jsonStats =  (JSONObject)pokemon.get("stats");
        	
        	String jsonStatsValue = Long.toString((Long)jsonStats.get(statsType));
        	System.out.println("jsonstats value is " + jsonStatsValue);
        	if (statsValue.equals(jsonStatsValue) ) {
        		System.out.println("Match found for stats ");
	        	String s = "\n" + pokemon.toJSONString() + "\n";
        		response += s;
        	}
		}
		
		return response;
	}
	
public String filterByQty(int maxRecords) {
	String response = "";
	
    // read the json file
	
    if (maxRecords > returnList.size()) maxRecords = returnList.size();
    
//    System.out.println(pokemonList.get(0));
//    System.out.println(pokemonList.get(1));
    for (int i = 0; i < maxRecords; i++) {
    	JSONObject pokemon = (JSONObject)returnList.get(i);
    	this.returnList.add(pokemon);
    	String s = "\n" + pokemon.toJSONString() + "\n";
    	response += s;
    	System.out.println("The " + i + " element of the array: " + s );
    	String name = (String)pokemon.get("name");
    	System.out.println("pokemon name is " + name);
    	JSONArray types = (JSONArray)pokemon.get("types");
    	System.out.println("pokemon types is " + types);
    	JSONObject stats = (JSONObject)pokemon.get("stats");
    	System.out.println("pokemon stats is " + stats);
    }
    return response;
}
	
	public String sort(String sortKey) {
			//get sort field and value
		String returnStr = "";
		if (sortKey.equals("name") || sortKey.startsWith("type") ) { // Perform String based sort
		    Collections.sort( this.returnList, new Comparator<JSONObject>() {
		        //You can change "Name" with "ID" if you want to sort by ID

		        @Override
		        public int compare(JSONObject a, JSONObject b) {
		            String valA = "";
		            String valB = "";

		            try {
		            	if (sortKey.contentEquals("name")) {
			            	valA = (String) a.get(sortKey);
			                System.out.println("value a is " + valA);
			                valB = (String) b.get(sortKey);
			                System.out.println("value b is " + valB);
		            	}

		            	else if  (sortKey.startsWith("type")) {
		            		System.out.println("sorting by types");
		            		// get the types id and value
		            		JSONArray typesA = (JSONArray) a.get("types");
		            		JSONObject tmpA = (JSONObject)typesA.get(0);
		            		JSONArray typesB = (JSONArray) b.get("types");
		            		JSONObject tmpB = (JSONObject)typesB.get(0);
			            	valA = (String) tmpA.get("id");
			                System.out.println("id a is " + valA);
			                valB = (String) tmpB.get("id");
			                System.out.println("id b is " + valB);

		            	}
		            
		            
		            } 
		            catch (Exception e) {
		                //do something
		            	e.printStackTrace();
		            }

		            return valA.compareTo(valB);
		            //if you want to change the sort order, simply use the following:
		            //return -valA.compareTo(valB);
		        }
		    });

		    for (int i = 0; i < returnList.size(); i++) {
		        returnStr += returnList.get(i).toJSONString();
		    }
		
		    return returnStr;
		} // end sort by name or type
		// The following is for base attack or base defense
	    Collections.sort( this.returnList, new Comparator<JSONObject>() {
	        //You can change "Name" with "ID" if you want to sort by ID

	        @Override
	        public int compare(JSONObject a, JSONObject b) {
	            Long valA = 0L;
	            Long valB = 0L;

	            try {
/*	            	if (sortkey.contentEquals("name")) {
		            	valA = (String) a.get(sortkey);
		                System.out.println("value a is " + valA);
		                valB = (String) b.get(sortkey);
		                System.out.println("value b is " + valB);
	            	}*/
	            	if (sortKey.equals("baseAttack") || 
	            			sortKey.equals("baseDefense") ||
	            			sortKey.equals("baseStamina")) {
	            		valA = (Long) ((JSONObject) a.get("stats")).get(sortKey);
	            		valB = (Long) ((JSONObject) b.get("stats")).get(sortKey);
		                System.out.println("value a is " + valA);
		                System.out.println("value b is " + valB);
	            	}
	            	

	            } 
	            catch (Exception e) {
	                //do something
	            	e.printStackTrace();
	            }

	            return valA.compareTo(valB);
	            //if you want to change the sort order, simply use the following:
	            //return -valA.compareTo(valB);
	        }
	    });

	    for (int i = 0; i < returnList.size(); i++) {
	        returnStr += returnList.get(i).toJSONString();
	    }
		return returnStr;
	}
	
	public String getAll() {
		String line="", myline="";
	    JSONParser parser = new JSONParser();

		  try { 
//        JSONObject a = (JSONObject) parser.parse(new FileReader("pokemon.json"));

    	BufferedReader in = new BufferedReader(new FileReader("pokemon.json"));
    	System.out.println(in);
    	int lineCount = 0;
    		while((line = in.readLine()) != null)
    		{
    			System.out.println("looping");
    		     myline =  myline + "<BR>" + line; 
    		     lineCount++; 
 //   		     if (lineCount == 5) 	break;
    		}
    		in.close();
		//    System.out.println(myline);

    	}
    	catch(Exception e) { e.printStackTrace();
    	} 
		  return myline;
	}
	
	public String updateStats(String baseAttack, String  baseDefense, 
			String baseStamina, String name) {
		// Get the current 
		Long IBaseAttack = Long.parseLong(baseAttack);
		Long IBaseDefense= Long.parseLong(baseDefense);
		Long IBaseStamina= Long.parseLong(baseStamina);

		for (int i = 0 ; i < this.returnList.size(); i++) {
			JSONObject record = returnList.get(i);
			System.out.println("Pokemon Name " + name); 
			System.out.println("record dex " + record.get("name")); 

			if(name == record.get("name")  ) {
				JSONObject jstats = (JSONObject)record.get("stats");
				jstats.put("baseAttack",IBaseAttack);
				jstats.put("baseDefense",IBaseDefense);
				jstats.put("baseStamina",IBaseStamina);
				
				return "record udpated";
			}
		}

		return "Record Not Updated. Please check name" + name + IBaseAttack;
	}

	public String getUserPokemon(String name) {
		String response = "";
		
		for (int i = 0 ; i < returnList.size() ; i++ ) {
			JSONObject record = returnList.get(i);
			if(name.equals((String)record.get("name")) ) {
				response+= record.toJSONString();
				break;
			}
		}
		return response;
	}
	
	
}






